package com.sai.offerPrice.OfferPriceCalculator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OfferPriceCalculatorApplicationTests {

	@Test
	void contextLoads() {
	}

}
