package com.sai.offerPrice.OfferPriceCalculator.service;

public class offerService {
    public static String findValue(int price) {
        long offerPrice= (long) (price*0.8f);
        return "Original Price : " + price +
                "<br> Discount : 20%" +
                "<br> Offer Price : " + offerPrice;

    }
}
