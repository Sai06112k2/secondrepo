package com.sai.offerPrice.OfferPriceCalculator.controller;

import com.sai.offerPrice.OfferPriceCalculator.service.offerService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/{price}")
public class OfferController {

    @GetMapping
    public ResponseEntity<String> findOfferValue(@PathVariable int price){
        return ResponseEntity.status(HttpStatus.OK).body(offerService.findValue(price));
    }
}
