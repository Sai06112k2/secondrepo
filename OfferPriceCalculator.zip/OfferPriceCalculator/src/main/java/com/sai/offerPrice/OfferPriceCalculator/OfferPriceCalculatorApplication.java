package com.sai.offerPrice.OfferPriceCalculator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OfferPriceCalculatorApplication {

	public static void main(String[] args) {
		SpringApplication.run(OfferPriceCalculatorApplication.class, args);
	}

}
